package org.campus02;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ChargingStationTest {
    @BeforeEach
    void setUp() {

    }

    @Test
    @DisplayName("Power per Minute Test")
    void powerPerMinute() {
        Assertions.assertEquals(10,5);
    }

    @Test
    @DisplayName("Kosten berechnen")
    void calculateCosts() {
        double expected = 5;
        Assertions.assertEquals(expected,setChargingStationRate(22));


    }

    @Test
    @DisplayName("Test der Tarife")
    void Chargingstation() {
        String expected = "Standart";
        String actual = getChargingStationRate("");
        Assertions.assertEquals(expected, actual);

        String expected = "Fix";
        String actual = getChargingStationRate();
        Assertions.assertEquals(expected, actual);
        String expected = "Smart";
        String actual = getChargingStationRate();
        Assertions.assertEquals(expected, actual);
        String expected = "falscher ChargingStationTarif gewählt";
        String actual = getChargingStationRate();
        Assertions.assertEquals(expected, actual);
    }

    @Test
    void setChargingStationRate() {
    }

    @Test
    void getFixCosts() {
    }

    @Test
    void setFixCosts() {
    }

    @Test
    void getVarCosts() {
    }

    @Test
    void setVarCosts() {
    }
    @Test
    @DisplayName("Test des Konstruktors")
            void ChargingStation(){
        setChargingStationRate();
        Assertions.assertEquals(5,setChargingStationRate());

        setFixCosts(10);
        Assertions.assertEquals(10,getFixCosts());

        setVarCosts(10);
        Assertions.assertEquals(10, getVarCosts());

    }

}