
Name: Daniel Gersdorf
Mail-Adresse: daniel.gersdorf@edu.campus02.at
Datum: 03.05.2023